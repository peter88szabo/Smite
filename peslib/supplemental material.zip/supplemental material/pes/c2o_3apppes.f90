module nnparam
    implicit none
    real(8), parameter :: alpha = 1.0
    real(8), parameter :: PI = 3.141592653589793238
    real(8), parameter :: radian = PI / 180.0
    real(8), parameter :: bohr = 0.5291772083, hartree = 0.03674931
    integer, parameter :: natom = 3
    integer, parameter :: nbond = natom * (natom - 1) / 2
    integer, parameter :: two_input = 1, noutput = 1, three_input = 3
    integer, parameter :: co_hiden1 = 6, co_hiden2 = 6, c2_hiden1 = 6, c2_hiden2 = 6, c2o_hiden1 = 14, c2o_hiden2 = 14
    real(8), allocatable :: w1_co(:), w2_co(:,:), w3_co(:)
    real(8), allocatable :: b1_co(:), b2_co(:), b3_co(:)
    real(8), allocatable :: w1_c2(:), w2_c2(:,:), w3_c2(:)
    real(8), allocatable :: b1_c2(:), b2_c2(:), b3_c2(:)
    real(8), allocatable :: w1_c2o(:,:), w2_c2o(:,:), w3_c2o(:)
    real(8), allocatable :: b1_c2o(:), b2_c2o(:), b3_c2o(:)
    
    logical :: weights_co_loaded = .false.
    logical :: weights_c2_loaded = .false.
    logical :: weights_c2o_loaded = .false.

contains
    function calculate_total_potential(X_cal) result(V_total)
        implicit none
        real(8) :: X_cal(9)
        real(8) :: r1, r2, r3, E_co_1, E_co_2, E_c2, E_c2o
        real(8) :: V_total
        real(8) :: X_bohr(9)

        X_bohr = X_cal * bohr
        call cartesian_to_internal(X_bohr, r1, r2, r3)
        call load_weights_biases_co()
        call load_weights_biases_c2()
        call load_weights_biases_c2o()
        call calculate_co_potential(r1, E_co_1)
        call calculate_co_potential(r2, E_co_2)
        call calculate_c2_potential(r3, E_c2)
        call calculate_c2o_potential(r1, r2, r3, E_c2o)
        V_total = (E_c2o*(0.5-0.5*tanh((r1-5.3)*1))*(0.5-0.5*tanh((r2-5.3)*1))*(0.5-0.5*tanh((r3-4.7)*1)) + E_co_1 + E_co_2 + E_c2 ) * hartree
    end function calculate_total_potential

    subroutine cartesian_to_internal(x_c, r1, r2, r3)
        implicit none
        integer i
        real(8) :: xcart(3, 3)
        real(8) :: x_c(9)
        real(8) :: r1, r2, r3

        do i = 1, 3
            xcart(1,i) = x_c(3*(i-1)+1)
            xcart(2,i) = x_c(3*(i-1)+2)
            xcart(3,i) = x_c(3*(i-1)+3)
        end do        
        
        r1 = SQRT(DOT_PRODUCT(xcart(:,1) - xcart(:,2), xcart(:,1) - xcart(:,2))) 
        r2 = SQRT(DOT_PRODUCT(xcart(:,1) - xcart(:,3), xcart(:,1) - xcart(:,3)))
        r3 = SQRT(DOT_PRODUCT(xcart(:,2) - xcart(:,3), xcart(:,2) - xcart(:,3)))
    end subroutine cartesian_to_internal
	
    subroutine load_weights_biases_co()
        implicit none
        integer i, j
        if (.not. weights_co_loaded) then
            if (allocated(w1_co)) deallocate(w1_co)
            if (allocated(w2_co)) deallocate(w2_co)
            if (allocated(w3_co)) deallocate(w3_co)
            if (allocated(b1_co)) deallocate(b1_co)
            if (allocated(b2_co)) deallocate(b2_co)
            if (allocated(b3_co)) deallocate(b3_co)
            allocate(w1_co(co_hiden1))
            allocate(w2_co(co_hiden2, co_hiden1))
            allocate(w3_co(co_hiden2))
            allocate(b1_co(co_hiden1))
            allocate(b2_co(co_hiden2))
            allocate(b3_co(1))

            open(unit=666, file='co_biases.txt')
            do i = 1, co_hiden1
                read(666, *) b1_co(i)
            end do
            do i = 1, co_hiden2
                read(666, *) b2_co(i)
            end do
            read(666, *) b3_co(1)
            close(666)

            ! Load weights from file
            open(unit=777, file='co_weights.txt')
            do i = 1, co_hiden1
                read(777, *) w1_co(i)
            end do
            do i = 1, co_hiden2
                do j = 1, co_hiden1
                    read(777, *) w2_co(i, j)
                end do
            end do
            do i = 1, co_hiden2
                read(777, *) w3_co(i)
            end do
            close(777)
            weights_co_loaded = .true.
        end if
    end subroutine load_weights_biases_co            

    subroutine load_weights_biases_c2()
        implicit none
        integer i, j
        if (.not. weights_c2_loaded) then
            if (allocated(w1_c2)) deallocate(w1_c2)
            if (allocated(w2_c2)) deallocate(w2_c2)
            if (allocated(w3_c2)) deallocate(w3_c2)
            if (allocated(b1_c2)) deallocate(b1_c2)
            if (allocated(b2_c2)) deallocate(b2_c2)
            if (allocated(b3_c2)) deallocate(b3_c2)

            allocate(w1_c2(c2_hiden1))
            allocate(w2_c2(c2_hiden2, c2_hiden1))
            allocate(w3_c2(c2_hiden2))
            allocate(b1_c2(c2_hiden1))
            allocate(b2_c2(c2_hiden2))
            allocate(b3_c2(1))
            open(unit=888, file='c2_biases.txt',status='old')
            do i = 1, c2_hiden1
                read(888, *) b1_c2(i)
            end do
            do i = 1, c2_hiden2
                read(888, *) b2_c2(i)
            end do
            read(888, *) b3_c2(1)
            close(888)

            ! Load weights from file
            open(unit=555, file='c2_weights.txt')
            do i = 1, c2_hiden1
                read(555, *) w1_c2(i)
            end do
            do i = 1, c2_hiden2
                do j = 1, c2_hiden1
                    read(555, *) w2_c2(i, j)
                end do
            end do
            do i = 1, c2_hiden2
                read(555, *) w3_c2(i)
            end do
            close(555) 
            weights_c2_loaded = .true.
        end if
    end subroutine load_weights_biases_c2        
        
        
       
    subroutine load_weights_biases_c2o()
        implicit none
        integer i, j

        if (.not. weights_c2o_loaded) then
            if (allocated(w1_c2o)) deallocate(w1_c2o)
            if (allocated(w2_c2o)) deallocate(w2_c2o)
            if (allocated(w3_c2o)) deallocate(w3_c2o)
            if (allocated(b1_c2o)) deallocate(b1_c2o)
            if (allocated(b2_c2o)) deallocate(b2_c2o)
            if (allocated(b3_c2o)) deallocate(b3_c2o)

            allocate(w1_c2o(c2o_hiden1, three_input))
            allocate(w2_c2o(c2o_hiden2, c2o_hiden1))
            allocate(w3_c2o(c2o_hiden2))
            allocate(b1_c2o(c2o_hiden1))
            allocate(b2_c2o(c2o_hiden2))
            allocate(b3_c2o(1))

            open(unit=111, file='c2o_biases.txt')
            do i = 1, c2o_hiden1
                read(111, *) b1_c2o(i)
            end do
            do i = 1, c2o_hiden2
                read(111, *) b2_c2o(i)
            end do
            read(111, *) b3_c2o(1)
            close(111)

            ! Load weights from file
            open(unit=222, file='c2o_weights.txt')
            do i = 1, c2o_hiden1
              do j = 1, three_input
                read(222, *) w1_c2o(i, j)
              end do
            end do
            do i = 1, c2o_hiden2
                do j = 1, c2o_hiden1
                    read(222, *) w2_c2o(i, j)
                end do
            end do
            do i = 1, c2o_hiden2
                read(222, *) w3_c2o(i)
            end do
            close(222)
            weights_c2o_loaded = .true.
        end if
    end subroutine load_weights_biases_c2o

    subroutine calculate_co_potential(r1, E_co)
        implicit none
        real(8) :: r1
        real(8) :: E_co
        real(8) :: f1(co_hiden1), f2_sum(co_hiden2)
        integer :: i, j

        do i = 1, co_hiden1
            f1(i) = b1_co(i) + w1_co(i) * r1
            f1(i) = tanh(f1(i))  
        end do
  
        f2_sum = 0.0
        do i = 1, co_hiden2
            do j = 1, co_hiden1
                f2_sum(i) = f2_sum(i) + w2_co(i, j) * f1(j)
            end do 
            f2_sum(i) = f2_sum(i) + b2_co(i)
            f2_sum(i) = tanh(f2_sum(i))
        end do

        E_co = 0.0
        do j = 1, co_hiden2
            E_co = E_co + w3_co(j) * f2_sum(j)
        end do
        E_co = E_co + b3_co(1)
  
    end subroutine calculate_co_potential        
	
    subroutine calculate_c2_potential(r3, E_c2)
        implicit none
        real(8), intent(in) :: r3
        real(8), intent(out) :: E_c2
        real(8) :: f1(c2_hiden1), f2_sum(c2_hiden2)
        integer :: i, j

        do i = 1, c2_hiden1
            f1(i) = b1_c2(i) + w1_c2(i) * r3
            f1(i) = tanh(f1(i)) 
        end do
  
        f2_sum = 0.0
        do i = 1, c2_hiden2
            do j = 1, c2_hiden1
                f2_sum(i) = f2_sum(i) + w2_c2(i, j) * f1(j)
            end do 
            f2_sum(i) = f2_sum(i) + b2_c2(i)
            f2_sum(i) = tanh(f2_sum(i))
        end do

        E_c2 = 0.0
        do j = 1, c2_hiden2
            E_c2 = E_c2 + w3_c2(j) * f2_sum(j)
        end do
        E_c2 = E_c2 + b3_c2(1)
  
    end subroutine calculate_c2_potential

    subroutine calculate_c2o_potential(r1, r2, r3, E_c2o)
        implicit none
        real(8), intent(in) :: r1, r2, r3
        real(8), intent(out) :: E_c2o
        real(8) :: g1, g2, g3
        real(8) :: f1_sum(c2o_hiden1), f2_sum(c2o_hiden2), E_end
		real(8), dimension(3) :: g
        integer :: i, j
        
        g1 = (exp(-r1) + exp(-r2)) / 2.0
        g2 = exp(-r1) * exp(-r2)
        g3 = exp(-r3)
        g(1) = g1
        g(2) = g2
        g(3) = g3

        f1_sum = 0.0
        do i = 1, c2o_hiden1
            do j = 1, three_input
                f1_sum(i) = f1_sum(i) + w1_c2o(i, j) * g(j)
            end do 
            f1_sum(i) = f1_sum(i) + b1_c2o(i)
            f1_sum(i) = tanh(f1_sum(i))  
        end do
  
        f2_sum = 0.0
        do i = 1, c2o_hiden2
            do j = 1, c2o_hiden1
                f2_sum(i) = f2_sum(i) + w2_c2o(i, j) * f1_sum(j)
            end do 
            f2_sum(i) = f2_sum(i) + b2_c2o(i)
            f2_sum(i) = tanh(f2_sum(i))
        end do

        E_end = 0.0
        do j = 1, c2o_hiden2
            E_end = E_end + w3_c2o(j) * f2_sum(j)
        end do
        E_end = E_end + b3_c2o(1)
		E_c2o = E_end
       
    end subroutine calculate_c2o_potential

end module nnparam
