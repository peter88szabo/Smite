!***************************************************************************
!                         PIP-NN PES for Ta+ + CO2
!***************************************************************************
!-->  program to get potential energy for a given geometry
!-->  global variables are declared in this module
!-->  Modified by Yang Liu on 2 November 2020
      module nnparam
      implicit none
!***************************************************************************
!natom     ==>Number of atoms
!npes      ==>Number of PESs
!nmorse    ==>Number of morse-like potential
!mass      ==>atomic mass
!***************************************************************************
      real*8,parameter::alpha=1.6d0 !angstrom
     &,pi=dacos(-1d0)
     %,radian=PI/180.0d0,bohr=0.5291772d0
      integer,parameter::natom=4,npes=3,nmorse=17
      integer,parameter::nbond=natom*(natom-1)/2
      integer ninput,noutput,nscale
      integer nhid3,nlayer3,ifunc3
      integer nwe3,nodemax3
      real*8 mass(4)
      integer,allocatable::nodes3a(:)
      real*8,allocatable::weight3a(:,:,:,:),bias3a(:,:,:),
     %pdel3a(:,:),pavg3a(:,:)
      data mass /1.007825d0,1.007825d0,14.003074d0,14.003074d0/  !H H N N
      integer np1,np2
      real*8,allocatable::x1(:),y1(:),y21(:),x2(:),y2(:),y22(:)
      end module nnparam

!***************************************************************************
      subroutine n2h2pes_Jcb(Jcb,v,vsr,vlr)
!     subroutine n2h2pes_Jcb(Jcb,v,vsr,vlr,els,eind,disp)
!***************************************************************************
!Compute the entire potential energy (Vsr + Vlr) in Jacobi coordinate
!v:    entire PES (v = vsr + vlr)
!vsr:  short range PES
!vlr:  long range PES
!els:  electrostatic (quadrupole − quadrupole) term
!disp: dispersion term
!eind: induction term 
!***************************************************************************
      use nnparam, only: natom,mass
      implicit none
      integer i,j,k
      double precision::xyz(3,natom),xt(natom,3),Jcb(6),Jcb1(6)  ! in bohr and degree
      double precision::EF(3),Rc,sw,vsr,vlr,v,els,eind,disp,vh2,vn2

      Jcb1=Jcb

      call JcbToCts(mass,Jcb1,xt)

!      write(*,'(3f20.10)') xt(1,:)*0.5291772d0  
!      write(*,'(3f20.10)') xt(2,:)*0.5291772d0
!      write(*,'(3f20.10)') xt(3,:)*0.5291772d0
!      write(*,'(3f20.10)') xt(4,:)*0.5291772d0
!      stop

      do i=1,3
       xyz(i,:)=xt(:,i)
      end do
      call PES_SR(xyz,vsr)
      call LR_PES(Jcb1,els,eind,disp,vlr)
      call H2_pot(Jcb1(2),vh2)
      call N2_pot(Jcb1(3),vn2)
      vlr=vlr+vh2+vn2

      Rc=Jcb1(1)
      sw=1.d0/(1+exp(-2.d0*(Rc-13.5d0)))

      v=(1-sw)*vsr + sw*vlr

      return
      end subroutine n2h2pes_Jcb

!***************************************************************************
      subroutine n2h2pes_cts(xyz,v,vsr,vlr)
!***************************************************************************
!Compute the entire potential energy (Vsr + Vlr) in Cartesian coordinate
!***************************************************************************
      use nnparam, only: natom,mass
      implicit none
      integer i,j,k
      double precision::xyz(3,natom),xt(natom,3),xyz1(3,natom)
     &,Jcb(6),Jcb1(6) ! in bohr and degree
      double precision::EF(3),Rc,sw,vsr,vlr,v,els,eind,disp,vh2,vn2

      xyz1=xyz
      do i=1,3
       xt(:,i)=xyz(i,:)
      end do

      call CtsToJcb(mass,xt,Jcb)
      Jcb1=Jcb
      call PES_SR(xyz1,vsr)
      call LR_PES(Jcb1,els,eind,disp,vlr)
      call H2_pot(Jcb1(2),vh2)
      call N2_pot(Jcb1(3),vn2)
      vlr=vlr+vh2+vn2

      Rc=Jcb1(1)
      sw=1.d0/(1+exp(-2.d0*(Rc-12.5d0)))

      v=(1-sw)*vsr + sw*vlr

      return
      end subroutine n2h2pes_cts

************************************************************************
      subroutine PES_SR(xcart,v)
!***************************************************************************
!Subroutine to calculate the potential energy v
!Call pes_init to read files and initialize before calling PES_SR().
!Xcart     ==>Cartesian coordinates in angstrom
!             H1: xcart(1,1), xcart(2,1), xcart(3,1)
!             H2: xcart(1,2), xcart(2,2), xcart(3,2)
!             N3: xcart(1,3), xcart(2,3), xcart(3,3)
!             N4: xcart(1,4), xcart(2,4), xcart(3,4)
!v         ==>potential energy(in cm-1)
!RMSE: 0.17 cm-1
!***************************************************************************
      use nnparam
      implicit none
      integer i,j,k,ndriv
      real*8 v,vpes(npes),c(0:ninput),dvdx(1:natom*3,npes)
      real*8 xcart(1:3,1:natom),m(0:nmorse-1),xmorse(1:nbond),r(1:nbond)
      real*8 dvdr(1:nbond),x(1:natom*3),drdx(1:nbond,1:natom*3)
      real*8 txinput(1:ninput),dvdg(1:ninput,npes),p(0:ninput)
      real*8 dpdr(1:nbond,0:ninput),dvdxa(1:natom*3)
!      do i=1,natom
!       x((3*(i-1)+1):(3*(i-1)+3))=xcart(:,i)*0.5291772d0
!      enddo

      xcart=xcart*0.5291772d0    ! to angstrom

      k=0
      do i=1,natom-1
       do j=i+1,natom
        k=k+1
       r(k)=dot_product(xcart(:,i)-xcart(:,j),
     $                  xcart(:,i)-xcart(:,j))
        r(k)=dsqrt(r(k))
        xmorse(k)=dexp(-r(k)/alpha)
       enddo
      enddo
      if(k.ne.natom*(natom-1)/2)stop "error"

      call bemsav(xmorse,m,p)

      do j=1,ninput
      txinput(j)=p(j)
      enddo

      call pot3a(txinput,vpes)
!     call pot3a(txinput,vpes,dvdg,ndriv)

      v=0d0 
      do i=1,npes
       v=v+vpes(i)
      enddo      

      v=v/npes                   
 
!      if(ndriv.eq.1)then
!       call evdvdr(r,c,m,p,dpdr!)
!       call evdrdx(xcart,r,x,drdx)
!       call evdvdx(dvdg,dpdr,drdx,dvdxa,dvdx)
!      endif
      
      return
      end subroutine PES_SR
!****************************************************************!
!-->  read NN weights and biases from matlab output
      subroutine pes_init_sr
      use nnparam
      implicit none
      integer i,j,ihid,iwe,inode1,inode2,ilay1,ilay2
      integer ibasis,npd,iterm,ib,nfile1,nfile2
      character f1*80

      nfile1=4
      nfile2=7
      open(nfile1,file='para_sr_weights.txt',status='old')
      open(nfile2,file='para_sr_biases.txt',status='old')

!       read(nfile1,*)
!       read(nfile2,*) 
       read(nfile1,*)ninput,nhid3,noutput
       nscale=ninput+noutput
       nlayer3=nhid3+2 !additional one for input layer and one for output 
       allocate(nodes3a(nlayer3),pdel3a(nscale,npes),
     &pavg3a(nscale,npes))
       nodes3a(1)=ninput
       nodes3a(nlayer3)=noutput
       read(nfile1,*)(nodes3a(ihid),ihid=2,nhid3+1)
       nodemax3=0
       do i=1,nlayer3
        nodemax3=max(nodemax3,nodes3a(i))
       enddo
       allocate(weight3a(nodemax3,nodemax3,2:nlayer3,npes),
     &bias3a(nodemax3,2:nlayer3,npes))
       read(nfile1,*)ifunc3,nwe3

      do j=1,npes
       if(j.gt.1) then
!        read(nfile1,*)
        read(nfile1,*)
        read(nfile1,*)
        read(nfile1,*)
!        read(nfile2,*)
       endif
       read(nfile1,*)(pdel3a(i,j),i=1,nscale)
       read(nfile1,*)(pavg3a(i,j),i=1,nscale)
       iwe=0
       do ilay1=2,nlayer3
       ilay2=ilay1-1
       do inode1=1,nodes3a(ilay1)
       do inode2=1,nodes3a(ilay2) !
       read(nfile1,*)weight3a(inode2,inode1,ilay1,j)
       iwe=iwe+1
       enddo
       read(nfile2,*)bias3a(inode1,ilay1,j)
       iwe=iwe+1
       enddo
       enddo
       if (iwe.ne.nwe3) then
         write(*,*)'provided number of parameters ',nwe3
         write(*,*)'actual number of parameters ',iwe
         write(*,*)'nwe not equal to iwe, check input files or code'
         stop
       endif
      enddo

      close(nfile1)
      close(nfile2)
!      write(*,*)'initialization done'

      end subroutine pes_init_sr
!*************************************************************************
      subroutine pot3a(x,vpot3)
!     subroutine pot3a(x,vpot3,dvdg,ndriv)
      use nnparam
      implicit none
      integer i,ndriv,inode1,inode2,ilay1,ilay2
      integer j,k,m,neu1,neu2
      real*8 x(ninput),y(nodemax3,nlayer3,npes),vpot3(npes)
      real*8,allocatable::nxw3(:,:),nxw2(:,:,:),nxw1(:,:,:)
      real*8,allocatable::ax(:,:),bx(:,:)
      real*8 vrange,girange(ninput)
      real*8 dvdg(1:ninput,npes),dvtmp(npes)
      real*8, external::tranfun

      dvdg=0d0
      dvtmp=0d0

      do m=1,npes
       do i=1,ninput
        y(i,1,m)=(x(i)-pavg3a(i,m))/pdel3a(i,m)
       enddo

!-->.....evaluate the hidden layer
       do ilay1=2,nlayer3-1
        ilay2=ilay1-1
        do inode1=1,nodes3a(ilay1)
         y(inode1,ilay1,m)=bias3a(inode1,ilay1,m)
         do inode2=1,nodes3a(ilay2)
          y(inode1,ilay1,m)=y(inode1,ilay1,m)+y(inode2,ilay2,m)
     &*weight3a(inode2,inode1,ilay1,m)
         enddo
         y(inode1,ilay1,m)=tranfun(y(inode1,ilay1,m),ifunc3)
        enddo
       enddo

!-->.....now evaluate the output
       ilay1=nlayer3
       ilay2=ilay1-1
       do inode1=1,nodes3a(ilay1)
        y(inode1,ilay1,m)=bias3a(inode1,ilay1,m)
        do inode2=1,nodes3a(ilay2)
         y(inode1,ilay1,m)=y(inode1,ilay1,m)+y(inode2,ilay2,m)
     &*weight3a(inode2,inode1,ilay1,m)
        enddo
       enddo

!-->.....the value of output layer is the fitted potential 
       vpot3(m)=y(nodes3a(nlayer3),nlayer3,m)
     &*pdel3a(nscale,m)+pavg3a(nscale,m)
      enddo

!      if(ndriv.eq.1)then
!       neu1=nodes3a(2);neu2=nodes3a(3)
!       allocate(nxw1(1:ninput,1:neu1,npes),nxw2(1:neu1,1:neu2,npes),
!     $ax(1:neu1,npes),bx(1:neu2,npes),nxw3(1:neu2,npes))
!       do m=1,npes
!        do i=1,ninput
!         do j=1,neu1
!          nxw1(i,j,m)=weight3a(i,j,2,m)
!         enddo
!        enddo
!        do j=1,neu1
!         do k=1,neu2
!          nxw2(j,k,m)=weight3a(j,k,3,m)
!         enddo
!        enddo
!        do j=1,neu1
!         ax(j,m)=y(j,2,m)
!        enddo
!        do k=1,neu2
!         bx(k,m)=y(k,3,m)
!         nxw3(k,m)=weight3a(k,1,4,m)
!        enddo
!
!        do i=1,ninput
!         do k=1,neu2
!          dvtmp=0d0
!          do j=1,neu1
!           dvtmp(m)=dvtmp(m)+nxw2(j,k,m)*nxw1(i,j,m)*(1d0-ax(j,m)**2)
!          enddo
!          dvdg(i,m)=dvdg(i,m)+nxw3(k,m)*dvtmp(m)*(1d0-bx(k,m)**2)
!         enddo
!         dvdg(i,m)=dvdg(i,m)*pdel3a(nscale,m)/pdel3a(i,m)
!        enddo
!
!       enddo
!      endif
            
      return
      end subroutine pot3a
!**************************************************************************
        function tranfun(x,ifunc)
        implicit none
        integer ifunc
        real*8 tranfun,x
c    ifunc=1, transfer function is hyperbolic tangent function, 'tansig'
c    ifunc=2, transfer function is log sigmoid function, 'logsig'
c    ifunc=3, transfer function is pure linear function, 'purelin'. It is imposed to the output layer by default
        if (ifunc.eq.1) then
        tranfun=dtanh(x)
        else if (ifunc.eq.2) then
        tranfun=1d0/(1d0+exp(-x))
        else if (ifunc.eq.3) then
        tranfun=x
        endif
        return
        end function tranfun
!**************************************************************************
        FUNCTION LOGSIG(X)
        REAL*8 X,LOGSIG
        LOGSIG=1.d0/(1.d0+DEXP(-X))
        RETURN
        END FUNCTION LOGSIG

!**************************************************************************
! N2 molecule potentail energy curve.
! 1D spline interpolation with ab initio calculation at 
!  CCSD(T)-F12A/avqz level.
! Ab initio calculations:
!**************************************************************************
! input:  r in bohr.
! output: v in cm^-1.
!**************************************************************************
      subroutine pes_init_n2
      use nnparam, only: x1,y1,y21,np1
      implicit none 
      integer i
      real*8 :: dy1,dyn

      np1=0
      dy1=1.d30
      dyn=1.d30

      open(202108,file='N2_ccsdt_avqz.txt',status='old')
      do
        read(202108,*,end=100)
        np1=np1+1
      enddo
100   continue
      close(202108)
      allocate( x1(np1),y1(np1),y21(np1) )
      open(202108,file='N2_ccsdt_avqz.txt',status='old')
      do i=1,np1
        read(202108,*) x1(i),y1(i)
      enddo
      close(202108)
      y1=(y1+110.596921859088d0)*219474.6314d0 ! hartree to cm^-1
      call spline(x1,y1,np1,dy1,dyn,y21)
      end
!**************************************************************************
      subroutine N2_pot(r,v)
      use nnparam, only: x1,y1,y21,np1
      implicit none
      integer :: i
      real*8 :: r,v
      real*8 :: rNN

      if (r.lt.1.815d0) then
         rNN=1.815d0
      elseif (r.gt.2.470d0) then
         rNN=2.470d0
      else
         rNN=r
      endif

      call splint(x1,y1,y21,np1,rNN,v)

      return
      end
!**************************************************************************
! N2 molecule potentail energy curve.
! 1D spline interpolation with ab initio calculation at 
!  CCSD(T)-F12A/avqz level.
! Ab initio calculations:
!**************************************************************************
! input:  r in bohr.
! output: v in cm^-1.
!**************************************************************************
      subroutine pes_init_h2
      use nnparam, only: x2,y2,y22,np2
      implicit none
      integer i
      real*8 :: dy1,dyn

      np2=0
      dy1=1.d30
      dyn=1.d30

      open(202108,file='H2_ccsdt_avqz.txt',status='old')
      do
        read(202108,*,end=100)
        np2=np2+1
      enddo
100   continue
      close(202108)
      allocate( x2(np2),y2(np2),y22(np2) )
      open(202108,file='H2_ccsdt_avqz.txt',status='old')
      do i=1,np2
        read(202108,*) x2(i),y2(i)
      enddo
      close(202108)
      y2=(y2+110.596921854413d0)*219474.6314d0 ! hartree to cm^-1
!     y2=(y2+1.174570041680d0)*219474.6314d0 ! hartree to cm^-1
      call spline(x2,y2,np2,dy1,dyn,y22)
      end
!**************************************************************************
      subroutine H2_pot(r,v)
      use nnparam, only: x2,y2,y22,np2
      implicit none
      integer :: i
      real*8 :: r,v
      real*8 :: rHH

      if (r.lt.0.94d0) then
         rHH=0.94d0
      elseif (r.gt.2.45d0) then
         rHH=2.45d0
      else
         rHH=r
      endif

      call splint(x2,y2,y22,np2,rHH,v)

      return
      end

!**************************************************************************
!  SPLINE ROUTINES
!             Numerical recipes in fortran
!             Cambrige University Press
!             York, 2nd edition, 1992.
!**************************************************************************
      SUBROUTINE splint(xa,ya,y2a,n,x,y)
      implicit double precision  (a-h,o-z)
      DIMENSION xa(n),y2a(n),ya(n)
      klo=1
      khi=n
 1    if (khi-klo.gt.1) then
        k=(khi+klo)/2
        if(xa(k).gt.x)then
          khi=k
        else
          klo=k
        endif
      goto 1
      endif
      h=xa(khi)-xa(klo)
      if (h.eq.0.0d0) write(6,*) 'bad xa input in splint'
      a=(xa(khi)-x)/h
      b=(x-xa(klo))/h
      y=a*ya(klo)+b*ya(khi)+((a**3-a)*y2a(klo)+(b**3-b)*y2a(khi))*(h**
     *2)/6.0d0
      return
      END
!**************************************************************************
      SUBROUTINE spline(x,y,n,yp1,ypn,y2)
      implicit double precision  (a-h,o-z)
      DIMENSION x(n),y(n),y2(n)
      PARAMETER (NMAX=1000)
      DIMENSION u(NMAX)
      if (yp1.gt..99d30) then
        y2(1)=0.0d0
        u(1)=0.0d0
      else
        y2(1)=-0.5d0
        u(1)=(3.0d0/(x(2)-x(1)))*((y(2)-y(1))/(x(2)-x(1))-yp1)
      endif
      do 11 i=2,n-1
        sig=(x(i)-x(i-1))/(x(i+1)-x(i-1))
        p=sig*y2(i-1)+2.0d0
        y2(i)=(sig-1.0d0)/p
        u(i)=(6.0d0*((y(i+1)-y(i))/(x(i+
     *1)-x(i))-(y(i)-y(i-1))/(x(i)-x(i-1)))/(x(i+1)-x(i-1))-sig*
     *u(i-1))/p
11    continue
      if (ypn.gt..99d30) then
        qn=0.0d0
        un=0.0d0
      else
        qn=0.5d0
        un=(3.0d0/(x(n)-x(n-1)))*(ypn-(y(n)-y(n-1))/(x(n)-x(n-1)))
      endif
      y2(n)=(un-qn*u(n-1))/(qn*y2(n-1)+1.0d0)
      do 12 k=n-1,1,-1
        y2(k)=y2(k)*y2(k+1)+u(k)
12    continue
      return
      END
!**************************************************************************

      subroutine bemsav(x,m,p)
      implicit none
      real*8,dimension(1:6),intent(in)::x
      real*8,dimension(0:32),intent(out)::p
      real*8,dimension(0:16)::m
      
      call evmono(x,m)
      call evpoly(m,p)
      
      return
      end subroutine bemsav
        
      subroutine evmono(x,m)
      implicit none
      real*8,dimension(1:6),intent(in)::x
      real*8,dimension(0:16),intent(out)::m
      
      m(0) = 1.0D0
      m(1) = x(6)
      m(2) = x(5)
      m(3) = x(4)
      m(4) = x(3)
      m(5) = x(2)
      m(6) = x(1)
      m(7) = m(3)*m(4)
      m(8) = m(2)*m(5)
      m(9) = m(2)*m(4)
      m(10) = m(3)*m(5)
      m(11) = m(2)*m(3)
      m(12) = m(4)*m(5)
      m(13) = m(2)*m(7)
      m(14) = m(2)*m(10)
      m(15) = m(2)*m(12)
      m(16) = m(3)*m(12)
      
      return
      end subroutine evmono
      
      subroutine evpoly(m,p)
      implicit none
      real*8,dimension(0:16),intent(in)::m
      real*8,dimension(0:32),intent(out)::p
          
      p(0) = m(0)
      p(1) = m(1)
      p(2) = m(2) + m(3) + m(4) + m(5)
      p(3) = m(6)
      p(4) = p(1)*p(2)
      p(5) = m(7) + m(8)
      p(6) = m(9) + m(10)
      p(7) = m(11) + m(12)
      p(8) = p(1)*p(3)
      p(9) = p(3)*p(2)
      p(10) = p(1)*p(1)
      p(11) = p(2)*p(2) - p(7) - p(6) - p(5) - p(7) - p(6) - p(5)
      p(12) = p(3)*p(3)
      p(13) = p(1)*p(5)
      p(14) = p(1)*p(6)
      p(15) = p(1)*p(7)
      p(16) = m(13) + m(14) + m(15) + m(16)
      p(17) = p(1)*p(9)
      p(18) = p(3)*p(5)
      p(19) = p(3)*p(6)
      p(20) = p(3)*p(7)
      p(21) = p(1)*p(4)
      p(22) = p(1)*p(11)
      p(23) = p(2)*p(5) - p(16)
      p(24) = p(2)*p(6) - p(16)
      p(25) = p(2)*p(7) - p(16)
      p(26) = p(1)*p(8)
      p(27) = p(3)*p(11)
      p(28) = p(1)*p(12)
      p(29) = p(3)*p(9)
      p(30) = p(1)*p(10)
      p(31) = p(2)*p(11) - p(25) - p(24) - p(23)
      p(32) = p(3)*p(12)
      
      return
      end subroutine evpoly
