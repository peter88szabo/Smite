* -->  call init (only once)
* -->  call pot(r,teta,tetb,phi,vpot) at each geometry      
*   r in Angstroms, th1,th2 and phi in radian, vtot in kcal/mol
      subroutine pes_init_lr  
      IMPLICIT REAL*8 (A-H,O-Z)
      parameter (maxc=70,maxl=15)
      common/exch/cex(maxc),lex(3,maxl),nex,irpowex,iwex,iexback
      common/spher/csp(maxc),lsp(3,maxl),nsp,irpowsp,iwsp,ispback
      common/damp/cdum(maxc),ldum(3,maxl),ndum

      call fct(40)
      call rdcoef

      return
      end 

      subroutine LR_PES(Jcb,els,eind,disp,vlr)
      implicit real*8 (a-h,o-z)
      parameter (maxc=70,maxl=15)
      dimension en(20), el(20), ei(20), ed(20)
      real*8 Jcb(6)
      common/damp/cdum(maxc),ldum(3,maxl),ndum

c---- conversion factors
      pi = dacos(-1.d0) 
      d2rad = pi/180.d0
      ao2A = 0.529177249

      r=Jcb(1)
      r1=Jcb(2)
      r2=Jcb(3)
      th1=Jcb(4)/180.d0*pi  
      th2=Jcb(5)/180.d0*pi
      phi=Jcb(6)/180.d0*pi

c---- call the asymptotics procedures.....
      call dispind(r,r1,r2,th1,th2,phi,ed,ei)
      call elst(r,r1,r2,th1,th2,phi,el)

      do i=1,20
       en(i) = 0.d0
      end do
      do i=1,12
c---- restrict electrostatics...
       if(i.gt.10) el(i) = 0.d0
       en(i) = en(i) + el(i) + ed(i) + ei(i)
      end do
      els = 0.d0
      eind = 0.d0
      disp = 0.d0    
      do i=1,12
       els = els + el(i)
       eind = eind + ei(i)
       disp = disp + ed(i)
      end do

      els=els/627.51d0*219474.6314d0
      eind=eind/627.51d0*219474.6314d0
      disp=disp/627.51d0*219474.6314d0

      vlr=els+eind+disp

      return
      end

      function dd(n,b,r)
      implicit real*8 (a-h,o-z)
      common/factorial/ f(0:40)
      br = b*r
      dd = b*dexp(-br)*(br)**n/f(n)
      return
      end
c
c Subroutine for the calculation of the multipole
c part of the dispersion and induction energies for a given
c dimer conformation. th1 and th2 expressed
c in radians. th1 is in fact equal to Pi-theta1,
c where theta1 is in the same coordinate system as theta2.
c
        subroutine dispind(R,r1,r2,th1,th2,phi,eld,eli)
        implicit real*8 (a-h,o-z)
        real*8,parameter::re_h2=1.449d0,re_n2=2.074d0 !bohr
        dimension rr(20), eld(20), eli(20)
        common/factorial/ f(0:40)
c--- common/dind/ contains dispersion and induction coefs.
        common/dind/ cd(6:12,0:10,0:10,0:20), ciab(6:12,0:10,0:10,0:20),
     1               ciba(6:12,0:10,0:10,0:20)
        data Pi /3.1415926535897932D0/
        data a0 /0.529177249d0/
        data efact /627.51d0/
        real*8 h2_alpha,n2_alpha
c
        rrev = 1.d0/R
        rr(1) = rrev
        do i=2,12
         rr(i) = rr(i-1)*rrev
        end do
        do i=1,12
         eld(i) = 0.d0
         eli(i) = 0.d0
        end do
c
        do n=6,12
        do la=0,8
        do lb=0,8
         lmin = abs(la-lb)
         lmax = la+lb
         molm = (-1)**lmax
        do l=lmin,lmax
         coed = cd(n,la,lb,l)
         coed = coed * h2_alpha(r1)/h2_alpha(re_h2)
     &*n2_alpha(r2)/n2_alpha(re_n2)
c ---- coei symmetrized ...
         coei = ciab(n,la,lb,l) + molm*ciba(n,lb,la,l)
         coei = coei * h2_alpha(r1)/h2_alpha(re_h2)
     &*n2_alpha(r2)/n2_alpha(re_n2)
         if(coei.eq.0.d0.and.coed.eq.0.d0) go to 1
         angterm = al1l2l0(la,lb,l,th1,th2,phi)
         eld(n) = eld(n) + coed*rr(n)*angterm
         eli(n) = eli(n) + coei*rr(n)*angterm
 1       continue
        end do
        end do
        end do
        end do
        do i=6,12
         eli(i) = -efact*eli(i)
         eld(i) = -efact*eld(i)
        end do
        return
        end

c
c Subroutine for the calculation of the multipole
c part of the electrostatic energy for a given
c dimer conformation. th1 and th2 expressed
c in radians. th1 is in fact equal to Pi-theta1,
c where theta1 is in the same coordinate system as theta2.
c
        subroutine elst(R,r1,r2,th1,th2,phi,el)
        implicit real*8 (a-h,o-z)
        dimension el(20), rrev(20)
        common/factorial/ f(0:40)
c--- common/mulprod/ contains products of multipole moments
c--- the mixed products NOT multiplied by 2 !!!
        common/mulprod/ Q(10,10), nmoma, nmomb
        data Pi /3.1415926535897932D0/
        data efact /627.51d0/
        data a0 /0.529177249d0/
        real*8 h2_quad,n2_quad
c
        rrev(1) = 1.d0/R
        do i=2,20
         rrev(i) = rrev(i-1)*rrev(1)
        end do
c
         els = 0.d0
        do i=1,20
         el(i) = 0.d0
        end do
c
        q(2,2)=h2_quad(r1)*n2_quad(r2)
!       write(*,'(3f8.3)')h2_quad(r1),n2_quad(r2),q(2,2)
        do la=2,2
        do lb=2,2
         if(q(la,lb).eq.0.d0) go to 1
         ll = la + lb
         mola = (-1)**la
         glam = mola*al1l2l0(la,lb,ll,th1,th2,phi)*q(la,lb)
         term = dsqrt(f(2*ll+1)/(f(2*la)*f(2*lb)))*glam*rrev(ll+1)
         els = els + term
         el(ll+1) = el(ll+1) + term
 1      continue
        end do
        end do
        do i=1,20
         el(i) = efact*el(i)
        end do
        return

        end

c
c Read the dispersion ond induction coefficients
c The induction coefficients of B->A part are assumed to be
c computed by induct and that NO phase adjustment nor indices
c exchange has been performed on them. This subroutine
c performs the adjustment itself...
c
        subroutine rdcoef
        implicit real*8 (a-h,o-z)
        common/dind/ cd(6:12,0:10,0:10,0:20), ciab(6:12,0:10,0:10,0:20),
     1               ciba(6:12,0:10,0:10,0:20)
c
c       write(6,*)'RDcoef entered'
        open(unit=1,file='para_lr_coefd.dat',form='formatted')
        open(unit=2,file='para_lr_coefia-b.dat',form='formatted')
        open(unit=3,file='para_lr_coefib-a.dat',form='formatted')
c
c----- zero out the coefficients....
c
        do n=6,12
        do la=0,10
        do lb=0,10
        do l=0,20
         cd(n,la,lb,l) = 0.d0
         ciab(n,la,lb,l) = 0.d0
         ciba(n,la,lb,l) = 0.d0
        end do
        end do 
        end do
        end do
c
        do i=1,1000
         read(1,*,END=100)la,ka,lb,kb,l,n,c0,c1,ctot
         cd(n,la,lb,l) = ctot
        end do
 100    continue
        idisp = i-1
c       write(6,*)idisp,' nonzero dispersion coefficients read in'
c       do n=6,12
c       do la=0,10
c       do lb=0,10
c       do l=0,20
c        if(cd(n,la,lb,l).ne.0.d0) write(6,*) cd(n,la,lb,l)
c       end do
c       end do
c       end do
c       end do
        do i=1,1000
         read(2,*,END=200)la,ka,lb,kb,l,n,c0,c1,ctot
         ciab(n,la,lb,l) = ctot
        end do
 200    continue
        iindab = i-1
c       write(6,*)iindab,' nonzero A->B induction coefficients read in'
c       do n=6,12
c       do la=0,10
c       do lb=0,10
c       do l=0,20
c        if(ciab(n,la,lb,l).ne.0.d0) write(6,*) ciab(n,la,lb,l)
c       end do
c       end do
c       end do
c       end do
c
        do i=1,1000
         read(3,*,END=300)la,ka,lb,kb,l,n,c0,c1,ctot
         ciba(n,la,lb,l) = ctot
        end do
 300    continue
        iindba = i-1
c       write(6,*)iindba,' nonzero B->A induction coefficients read in'
c       do n=6,12
c       do la=0,10
c       do lb=0,10
c       do l=0,20
c        if(ciba(n,la,lb,l).ne.0.d0) write(6,*) ciba(n,la,lb,l)
c       end do
c       end do
c       end do
c       end do
c
        close(1)
        close(2)
        close(3)
        return
        end

!======================================================================
!--------------- Parametric functions ---------------------------------
      function h2_quad(r0)
      implicit none
      real*8 r0,h2_quad ! in bohr and hartree !
      real*8 r ! in bohr !
      real*8 a(7)
      r=r0 !*0.529177249d0
      a(:)=(/0.000791d0,-0.005230d0,0.003047d0,-0.046342d0,0.297513d0,
     &       0.011926d0,-0.004850d0/)
      if(r.lt.0.85d0) stop 'r is too small in quadrupole!'
      if(r.gt.2.548d0) stop 'r is too large in quadrupole!'
      h2_quad=a(1)*r**6+a(2)*r**5+a(3)*r**4+a(4)*r**3+a(5)*r**2+
     &        a(6)*r+a(7)

      return
      endfunction

      function n2_quad(r0)
      implicit none
      real*8 r0,n2_quad ! in bohr and hartree !
      real*8 r ! in bohr !
      real*8 a(7)
      r=r0 !*0.529177249d0
      a(:)=(/0.040375d0,-0.509610d0,2.408669d0,-5.210029d0,4.639238d0,
     &       0.874031d0,-4.631327d0/)
      if(r.lt.1.75d0) stop 'r is too small in quadrupole!'
      if(r.gt.2.58d0) stop 'r is too large in quadrupole!'
      n2_quad=a(1)*r**6+a(2)*r**5+a(3)*r**4+a(4)*r**3+a(5)*r**2+
     &        a(6)*r+a(7)

      return
      endfunction

      function h2_alpha(r0)
      implicit none
      real*8 r0,h2_alpha,p1,p2 ! in bohr and hartree !
      real*8 r ! in bohr !
      real*8 a1(7),a2(7)
      r=r0    !*0.529177249d0
      a1(:)=(/0.007436d0,-0.063350d0,0.196483d0,-0.595926d0,1.698282d0,
     &        0.797023d0,1.302225d0/)
      a2(:)=(/0.054112d0,-0.598819d0,2.191807d0,-3.829032d0,5.714229d0,
     &        -1.185609d0,1.752585d0/)
      p1=a1(1)*r**6+a1(2)*r**5+a1(3)*r**4+a1(4)*r**3+a1(5)*r**2+
     &        a1(6)*r+a1(7)
      p2=a2(1)*r**6+a2(2)*r**5+a2(3)*r**4+a2(4)*r**3+a2(5)*r**2+
     &        a2(6)*r+a2(7)
      h2_alpha=(p1*2d0+p2)/3d0

      return
      endfunction

      function n2_alpha(r0)
      implicit none
      real*8 r0,n2_alpha,p1,p2 ! in bohr and hartree !
      real*8 r ! in bohr !
      real*8 a1(7),a2(7)
      r=r0 !*0.529177249d0
      a1(:)=(/4.940865d0,-65.725586d0,362.106178d0,-1058.790007d0
     &,1734.563857d0,-1507.350714d0,549.902003d0/)
      a2(:)=(/-181.621282d0,2268.896757d0,-11796.468194d0,32663.616111d0
     &,-50786.282699d0,42038.847719d0,-14464.966293d0/)
      p1=a1(1)*r**6+a1(2)*r**5+a1(3)*r**4+a1(4)*r**3+a1(5)*r**2+
     &        a1(6)*r+a1(7)
      p2=a2(1)*r**6+a2(2)*r**5+a2(3)*r**4+a2(4)*r**3+a2(5)*r**2+
     &        a2(6)*r+a2(7)
      n2_alpha=(p1*2d0+p2)/3d0
      return
      endfunction

!      function h2_alga(r0)
!      implicit none
!      real*8 r0,h2_alga,p1,p2 ! in bohr and hartree !
!      real*8 r ! in bohr !
!      real*8 a1(7),a2(7)
!      r=r0 !*0.529177249d0
!      a1(:)=(/0.007436d0,-0.063350d0,0.196483d0,-0.595926d0,1.698282d0,
!     &        0.797023d0,1.302225d0/)
!      a2(:)=(/0.054112d0,-0.598819d0,2.191807d0,-3.829032d0,5.714229d0,
!     &        -1.185609d0,1.752585d0/)
!      p1=a1(1)*r**6+a1(2)*r**5+a1(3)*r**4+a1(4)*r**3+a1(5)*r**2+
!     &        a1(6)*r+a1(7)
!      p2=a2(1)*r**6+a2(2)*r**5+a2(3)*r**4+a2(4)*r**3+a2(5)*r**2+
!     &        a2(6)*r+a2(7)
!!     h2_alga=(p2-p1)/3.d0
!      h2_alga=(p2-p1)/(p2+2.d0*p1)
!      return
!      endfunction
!
!      function n2_alga(r0)
!      implicit none
!      real*8 r0,n2_alga,p1,p2 ! in bohr and hartree !
!      real*8 r ! in Angstrom !
!      real*8 a1(7),a2(7)
!      r=r0!*0.529177249d0
!      a1(:)=(/15.631338d0,-207.934869d0,1145.498341d0,-3347.593243d0,
!     &        5476.726940d0,-4755.361533d0,1719.732487d0/)
!      a2(:)=(/-188.911676d0,2381.753631d0,-12494.518775d0,
!     &        34898.969523d0,-54723.986673d0,45674.104244d0,
!     &        -15843.540664d0/)
!      p1=a1(1)*r**6+a1(2)*r**5+a1(3)*r**4+a1(4)*r**3+a1(5)*r**2+
!     &        a1(6)*r+a1(7)
!      p2=a2(1)*r**6+a2(2)*r**5+a2(3)*r**4+a2(4)*r**3+a2(5)*r**2+
!     &        a2(6)*r+a2(7)
!!     n2_alga=(p2-p1)/3.d0
!      n2_alga=(p2-p1)/(p2+2.d0*p1)
!      return
!      endfunction
!======================================================================
c 
c Compute the set of associated Legendre polynomials P_lm
c for l=0,1,...,lmax, and m=0,1,...,l. First the standard
c polynomials
c
c   P^m_l(x) = (1/2^l l!)(1-x^2)^(m/2) (d^(l+m)/d x^(l+m))(x^2 -1)^l
c
c are computed, and then multiplied by
c
c  (-1)^m sqrt[(2l+1)(l-m)!/2(l+m)!]/sqrt(2Pi)
c
c to get the P_lm polynomials....
c
        subroutine plm(p,x,lmax)
        implicit real*8 (a-h,o-z)
        dimension p(0:50,0:50)
        common/factorial/ fact(0:40)
c inverse of dsqrt(2Pi)
        data twopinv /0.3989422804014d0/
c
c starting value
c
        p(0,0) = 1.d0
        u = dsqrt(1-x*x)
c
c compute the diagonal elements
c
        do l=1,lmax
         p(l,l) = (2*l-1)*p(l-1,l-1)*u
        end do
c
c compute P_lm along the columns with fixed m
c
        do m = 0,lmax-1
        do l = m,lmax-1
         if((l-1).lt.m) then
           pp = 0
         else
           pp = p(l-1,m)
         endif
         p(l+1,m) = ((2*l+1)*x*p(l,m)-(l+m)*pp)/(l-m+1)
        end do 
        end do
c
c Renormalize values...
c
        do l=0,lmax
        mm = 1
        do m=0,l
         dnorm = fact(l-m)*(2*l+1)/(2*fact(l+m))
         p(l,m) = mm*twopinv*dsqrt(dnorm)*p(l,m)
         mm = -mm
        end do
        end do
c
        return
        end
c
c compute the matrix of N!
c
        subroutine fct(nmax)
        implicit real*8 (a-h,o-z)
        common/factorial/ f(0:40)
c       
        f(0) = 1.d0
        do i=1,nmax
         f(i) = f(i-1)*i
        end do
        return
        end
c
c Calculate the Clebsh-Gordan coefficient (or the 3-j symbol)
c The parameter ind3j.eq.1 indicates that the 3-J symbol is returned
c
        subroutine cgc(j1,m1,j2,m2,j,mm,value,ind3j)
        implicit real*8 (a-h,o-z)
        common/factorial/ f(0:40)        
c
        d3jfact = 1.d0
        m = mm
        if(ind3j.eq.1) then
         d3jfact = ((-1.d0)**(j1-j2-m))/dsqrt(dfloat(2*j+1))
         m = -mm
        endif
c
c Check the triangle conditions
c        
        if(j.gt.(j1+j2)) write(6,*)'triangle violated'
        if(j.lt.abs(j1-j2)) write(6,*)'triangle violated'
        if((m1+m2).ne.m) then
          value = 0.d0
          return
        endif
c
c Calculation proper... the pre-sum factor....
c
        facn = (2*j+1)*f(j1+j2-j)*f(j1-m1)*f(j2-m2)*f(j+m)*f(j-m)
        facd = f(j1+j2+j+1)*f(j+j1-j2)*f(j+j2-j1)*f(j1+m1)*f(j2+m2)
        fac = dsqrt(facn/facd)
c
c determine the limit of k summation...
c
        kmax = min(j2+j-m1,j-m,j1-m1)        
        if(kmax.lt.0) kmax = 0
        kmin = max(-j1-m1,-j2+j-m1,0)
c
c perform the summation (at least one cycle must be completed...
c
        sum = 0.d0
        do k = kmin,kmax
         facn = f(j1+m1+k)*f(j2+j-m1-k)
         facd = f(k)*f(j-m-k)*f(j1-m1-k)*f(j2-j+m1+k)
         sum = sum + (facn/facd)*(-1)**k
        end do
        value = d3jfact*fac*sum*(-1)**(j1-m1)
       return
       end
c
c Calculate the function Al1l2L for a given set of angles...
c It is assumed that the th1 and th2 angles are between the monomer bond
c and the "positive" part of the intermolecular (z) axis.
c
       function al1l2l0(l1,l2,l,th1,th2,phi)
       implicit real*8 (a-h,o-z)
       dimension p1(0:50,0:50), p2(0:50,0:50)
       data izer/0/, ione/1/, pifact/12.566370614359d0/
c
c       pi = dacos(-1.d0)
       c1 = dcos(th1)
       c2 = dcos(th2)
       call plm(p1,c1,l1)
       call plm(p2,c2,l2)
c       mmax = min(l1,l2,2)
c       mmax = min(l1,l2,1)
       mmax = min(l1,l2)
       sum = 0.d0
       do m=1,mmax
        call cgc(l1,m,l2,-m,l,izer,value,ione)
        sum = sum + (-1)**m*value*p1(l1,m)*p2(l2,m)*dcos(m*phi)
       end do
       call cgc(l1,0,l2,0,l,izer,value,ione)
       sum = 2*sum + value*p1(l1,0)*p2(l2,0)
c
       al1l2l0 = sum*pifact*(-1.d0)**(l1+l2+l)/dsqrt((2.d0*l1+1.d0)*
     1           (2.d0*l2+1.d0))
c
       return
       end
c
c Calculate the function Al1l2L for a given set of angles...
c It is assumed that the th1 and th2 angles are between the monomer bond
c and the "inner" part of the intermolecular axis.
c L stands for the m quantum number rather than real L...
c
       function al1l2l(l1,l2,l,th1,th2,phi)
       implicit real*8 (a-h,o-z)
       dimension p1(0:50,0:50), p2(0:50,0:50)
       data izer/0/, ione/1/, pifact/0.282094791d0/
c
       pi2 = 0.5d0*dacos(-1.d0)
       if(l.gt.l1.or.l.gt.l2) then
        write(6,*)'Cannot calculate l1, l1, l',l1,l2, l
        return
       endif
       c1 = dcos(th1)
       c2 = dcos(th2)
       call plm(p1,c1,l1)
       call plm(p2,c2,l2)
c       al1l2l = (th1-pi2)*(th1-pi2)*(th2-pi2)*(th2-pi2)*p1(l1,l)*
c     1          p2(l2,l)*dcos(l*phi)
c       al1l2l = ((th1-pi2)*(th1-pi2)+(th2-pi2)*(th2-pi2))*
c     1          p1(l1,l)*p2(l2,l)*dcos(l*phi)
c       al1l2l = dabs((th1-pi2)*(th2-pi2))*p1(l1,l)*p2(l2,l)*dcos(l*phi)
       al1l2l = p1(l1,l)*p2(l2,l)*dcos(l*phi)
       return
       end

!======================================================================
!coordinates
!======================================================================
      subroutine JcbToCts(mass,JcbQ,CtsQ)
c----------------------------------------------------------------------
c       This subroutine transforms AB+CD Jacobi coordinate (JcbQ) into
c       Cartesian coordinate (CtsQ). CtsQ(i,j) means the jth coordiante
c       of ith atom, with j in the sequence of x, y, and z.
c       JcbQ is (RR, r1, r2, th1, th2, phi).
c       Bond in a.u. and angle in rad.
c       AB is in the xy plain. The center of mass of AB is the origin.
c       R is placed onto the x axis.
c       r1 from A to B and r2 from C to D.
c       th1 is polar angle from R to r1.
c       th2 is polar angle from R to r2.
c       n1 is normal vector of R, r1. n2 is normal vector of R, r2.
c       phi is dihedral angle, or polar angle from n1 to n2.
c----------------------------------------------------------------------
      implicit none

      real*8,intent(in):: mass(4)
      real*8,intent(in):: JcbQ(6) ! bond in a.u. and angle in degree!
      real*8,intent(out):: CtsQ(4,3)

      real*8,parameter :: pi=dacos(-1d0)
      real*8 RR,r1,r2,th1,th2,phi
      real*8 b1,b2,b3,b4
      real*8 s1,s2,c1,c2,sp,cp

      b1=mass(1)/(mass(1)+mass(2))
      b2=mass(2)/(mass(1)+mass(2))
      b3=mass(3)/(mass(3)+mass(4))
      b4=mass(4)/(mass(3)+mass(4))
      RR=JcbQ(1)
      r1=JcbQ(2)
      r2=JcbQ(3)
      th1=JcbQ(4)
      th2=JcbQ(5)
      phi=JcbQ(6)
      s1=dsin(th1*pi/18d1)
      c1=dcos(th1*pi/18d1)
      s2=dsin(th2*pi/18d1)
      c2=dcos(th2*pi/18d1)
      sp=dsin(phi*pi/18d1)
      cp=dcos(phi*pi/18d1)

      CtsQ(1,1)=-b2*r1*c1
      CtsQ(1,2)=-b2*r1*s1
      CtsQ(1,3)=0.d0

      CtsQ(2,1)=b1*r1*c1
      CtsQ(2,2)=b1*r1*s1
      CtsQ(2,3)=0.d0

      CtsQ(3,1)=RR-b4*r2*c2
      CtsQ(3,2)=-b4*r2*s2*cp
      CtsQ(3,3)=-b4*r2*s2*sp

      CtsQ(4,1)=RR+b3*r2*c2
      CtsQ(4,2)=b3*r2*s2*cp
      CtsQ(4,3)=b3*r2*s2*sp

      return
      endsubroutine



      subroutine CtsToJcb(mass,CtsQ,JcbQ)
      implicit none

      real*8,intent(in):: mass(4)
      real*8,intent(in):: CtsQ(4,3)
      real*8,intent(out):: JcbQ(6) ! bond in a.u. and angle in degree !

      real*8,parameter :: pi=dacos(-1d0)
      real*8,dimension(3):: q_RR,q_r1,q_r2,q_n1,q_n2
      real*8 RR,r1,r2,cth1,cth2,cphi
      real*8 com1(3),com2(3)

      q_r1(:)=CtsQ(2,:)-CtsQ(1,:)
      q_r2(:)=CtsQ(4,:)-CtsQ(3,:)
      r1=distance(CtsQ(1,:),CtsQ(2,:))
      r2=distance(CtsQ(3,:),CtsQ(4,:))

      com1(:)=mass(2)/(mass(1)+mass(2))*q_r1(:)+CtsQ(1,:)
      com2(:)=mass(4)/(mass(3)+mass(4))*q_r2(:)+CtsQ(3,:)
      q_RR(:)=com2(:)-com1(:)
      RR=distance(com2,com1)
      cth1=cosine(q_RR,q_r1)
      cth2=cosine(q_RR,q_r2)

      call normal_vector(q_RR,q_r1,q_n1)
      call normal_vector(q_RR,q_r2,q_n2)
      cphi=cosine(q_n1,q_n2)

      if(dabs(cphi-1.d0).le.1.d-8) then
        cphi=1.0d0
      endif
      if(dabs(cphi+1.d0).le.1.d-8) then
        cphi=-1.0d0
      endif
      if(dabs(cth1-1.d0).le.1.d-8) then
        cth1=1.0d0
        cphi=1.0d0
      endif
      if(dabs(cth1+1.d0).le.1.d-8) then
        cth1=-1.0d0
        cphi=1.0d0
      endif
      if(dabs(cth2-1.d0).le.1.d-8) then
        cth2=1.0d0
        cphi=1.0d0
      endif
      if(dabs(cth2+1.d0).le.1.d-8) then
        cth2=-1.0d0
        cphi=1.0d0
      endif

      JcbQ(1)=RR
      JcbQ(2)=r1
      JcbQ(3)=r2
      JcbQ(4)=dacos(cth1)*18d1/pi
      JcbQ(5)=dacos(cth2)*18d1/pi
      JcbQ(6)=dacos(cphi)*18d1/pi

      return

      contains
        function distance(d1,d2)
        implicit none
        real*8 d1(3),d2(3)
        real*8 distance
        real*8 x1,y1,z1,x2,y2,z2

        x1=d1(1); y1=d1(2); z1=d1(3)
        x2=d2(1); y2=d2(2); z2=d2(3)
        distance=dsqrt((x1-x2)**2+(y1-y2)**2+(z1-z2)**2)

        return
        endfunction

        function cosine(q1,q2)
        implicit none
        real*8 q1(3),q2(3)
        real*8 cosine
        real*8 x1,y1,z1,x2,y2,z2
        real*8 q1q2,absq1,absq2

        x1=q1(1); y1=q1(2); z1=q1(3)
        x2=q2(1); y2=q2(2); z2=q2(3)
        q1q2=x1*x2+y1*y2+z1*z2
        absq1=dsqrt(x1**2+y1**2+z1**2)
        absq2=dsqrt(x2**2+y2**2+z2**2)
        cosine=q1q2/(absq1*absq2)
        if(absq1.le.1.d-8.or.absq2.le.1.d-8) then
          cosine=1.d0
        endif

        return
        endfunction

        subroutine normal_vector(a,b,ab)
        implicit none

        real*8,intent(in),dimension(3):: a,b
        real*8,intent(out):: ab(3)
        real*8 l,m,n,o,p,q

        l=a(1); m=a(2); n=a(3)
        o=b(1); p=b(2); q=b(3)
        ab(1)=m*q-n*p
        ab(2)=n*o-l*q
        ab(3)=l*p-m*o

        return
        endsubroutine
      endsubroutine

        subroutine change_atoms_order_Cts(C1,C2)
        implicit none
        real*8,intent(in) :: C1(4,3)
        real*8,intent(out):: C2(4,3)
        C2(1,:)=C1(1,:)
        C2(2,:)=C1(3,:)
        C2(3,:)=C1(2,:)
        C2(4,:)=C1(4,:)
        return
        endsubroutine

        subroutine change_atoms_order_q(q1,q2)
        implicit none
        real*8,intent(in) :: q1(3,4)
        real*8,intent(out):: q2(3,4)
        q2(:,1)=q1(:,1)
        q2(:,2)=q1(:,3)
        q2(:,3)=q1(:,2)
        q2(:,4)=q1(:,4)
        return
        endsubroutine


        subroutine xyz_to_bond(Cts,b)
        implicit none
        real*8,intent(in) :: Cts(4,3)
        real*8,intent(out):: b(6)
        integer j
        b(1)=bond(Cts(1,:),Cts(2,:))
        b(2)=bond(Cts(1,:),Cts(3,:))
        b(3)=bond(Cts(1,:),Cts(4,:))
        b(4)=bond(Cts(2,:),Cts(3,:))
        b(5)=bond(Cts(2,:),Cts(4,:))
        b(6)=bond(Cts(3,:),Cts(4,:))

        contains

        function bond(d1,d2)
        implicit none
        real*8 d1(3),d2(3)
        real*8 bond
        real*8 x1,y1,z1,x2,y2,z2

        x1=d1(1); y1=d1(2); z1=d1(3)
        x2=d2(1); y2=d2(2); z2=d2(3)
        bond=dsqrt((x1-x2)**2+(y1-y2)**2+(z1-z2)**2)

        return
        endfunction

        endsubroutine


        subroutine bond_to_xyz(rbond,q)
        implicit none
        real*8,intent (in) :: rbond(6)!in K-K-Rb-Rb order !
        real*8,intent (out):: q(3,4)
        integer j
        real*8 r12,r13,r14,r23,r24,r34
        real*8 x3,y3,x4,y4,z4,ztmp

        r12=rbond(1)
        r13=rbond(2)
        r14=rbond(3)
        r23=rbond(4)
        r24=rbond(5)
        r34=rbond(6)

!-----> K1(0,0,0)
        q=0.d0

!-----> K2(r12,0,0)
        q(1,2)=r12

!-----> Rb3(x3,y3,0)
        call triangle(r12,r13,r23,x3,y3)
        q(1,3)=x3
        q(2,3)=y3

!-----> Rb4(x4,y4,z4)
        call triangle(r12,r14,r24,x4,ztmp)
        q(1,4)=x4
        
        y4=((x4-x3)**2+y3**2+ztmp**2-r34**2)/(2d0*y3)
        if(dabs(ztmp-dabs(y4))<1d-1)then
          z4=0.d0
        else
          z4=dsqrt(ztmp**2-y4**2)
        endif
        !write(*,*)'ztmp=',ztmp
        !write(*,*)'y4',y4
        q(2,4)=y4
        q(3,4)=z4

        contains
               
          subroutine triangle(rac,rbc,rab,x,y)
          implicit none
          real*8,parameter :: pi=dacos(-1d0)
          real*8,intent (in) :: rac,rbc,rab
          real*8,intent (out):: x,y
          real*8 cth,theta
          cth=(rac**2+rbc**2-rab**2)/(2.d0*rac*rbc)
          theta=dacos(cth)*18d1/pi
          x=rbc*cth
          y=rbc*dsqrt(1-cth**2)
          return
          endsubroutine

        endsubroutine
