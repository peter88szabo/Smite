        program main
        implicit real*8(a-h,o-z)
        integer,parameter::natom=4
        real*8 Jcb(6)   !bond in bohr and angle in degree
!       JcbQ is (RR, r1, r2, th1, th2, phi).
!       Bond in bohr and angle in degree.
!       H1H2 is in the xy plain. The center of mass of H1H2 is the origin.
!       R is placed onto the x axis.
!       r1 from H1 to H2 and r2 from N1 to N2.
!       th1 is polar angle from R to r1.
!       th2 is polar angle from R to r2.
!       n1 is normal vector of R, r1. n2 is normal vector of R, r2.
!       phi is dihedral angle, or polar angle from n1 to n2.
        real*8 xyz(3,natom) !in bohr
!xyz    ==>Cartesian coordinates in angstrom
!             H1: xyz(1,1), xyz(2,1), xyz(3,1)
!             H2: xyz(1,2), xyz(2,2), xyz(3,2)
!             N3: xyz(1,3), xyz(2,3), xyz(3,3)
!             N4: xyz(1,4), xyz(2,4), xyz(3,4)
        real*8 r1,r2,N2_quad,N2_alpha,H2_quad,H2_alpha

!       initialization
        call pes_init_sr
        call pes_init_lr
        call pes_init_N2
        call pes_init_H2

        Jcb(2)=1.449d0
!       Jcb(2)=2.0d0
        Jcb(3)=2.0740d0
        Jcb(3)=2.380d0
        Jcb(4)=90d0
        Jcb(5)=90d0
        Jcb(6)=90d0
       
        do r=2.d0,25.01d0,0.1d0
         Jcb(1)=r/0.5291772d0
         call n2h2pes_Jcb(Jcb,v,vsr,vlr)     !Jacobi coordinates
!        call n2h2pes_cts(xyz,v,vsr,vlr)     !Cartesian coordinates
!        call n2h2pes_Jcb(Jcb,v,vsr,vlr,els,eind,disp)
         write(20,'(f8.4,6f15.5)')Jcb(1),v,vsr,vlr
        enddo

        end
